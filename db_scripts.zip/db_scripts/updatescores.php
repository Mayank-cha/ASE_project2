<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'collect_object';
$secretKey = "mySecretKey";
 
try 
{
	$dbh = new PDO('mysql:host='. $hostname .';dbname='. $database, 
           $username, $password);
} 
catch(PDOException $e) 
{
	echo '<h1>An error has ocurred.</h1><pre>', $e->getMessage() 
            ,'</pre>';
}

$hash = $_GET['hash'];
$realHash = hash('sha256', $_GET['name'] . $_GET['mode'] . $secretKey);
	
if($realHash == $hash) 
{
	
	$sth = $dbh->prepare('UPDATE scores SET score=:score WHERE ID = (Select MAX(ID) scores where name = :name and mode = :mode )') ;
	try 
	{
	    $sth->bindParam(':score', $_GET['score'], 
                  PDO::PARAM_INT);
		$sth->bindParam(':name', $_GET['name'], 
                  PDO::PARAM_STR);
		$sth->bindParam(':mode', $_GET['mode'], 
                  PDO::PARAM_INT);
		$sth->execute();
		echo 'Data saved to DB successfully' ;
	}
	catch(Exception $e) 
	{
		echo '<h1>An error has ocurred.</h1><pre>', 
                 $e->getMessage() ,'</pre>';
	}
}

?>